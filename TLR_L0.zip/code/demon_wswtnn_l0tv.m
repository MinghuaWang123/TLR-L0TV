%% WSWTNN-L0TV

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Minghua Wang (minghuawang1993@163.com)
% Last version: Jul. 27, 2019
% Article: Tensor Low-Rank Constraint and l0 Total Variation for Hyperspectral Image Mixed Noise Removal
% https://ieeexplore.ieee.org/document/9352482/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear;clc;

load Indiancom_case6.mat;

u_input=T;
[m,n,dim]=size(T);
mn=m*n;
Y=T;
S=zeros(m,n,dim);
u=Y-S;
imsize = size(u_input);

N = imsize(1)*(imsize(2)); % number of pixels
%%%%%%%%%%%%%%%%%%%%% User Settings %%%%%%%%%%%%%%%%%%%%%%%%%%%%
etol=10^(-4);

% beta = 1;
alpha_m=[1,1,0.001];
alpha_m=alpha_m/sum(alpha_m);
%% indian_01 
% beta = 0.4;                                                                                                                              ; % stepsize of ADMM 36.721678 dB SSIMΪ 0.9706
% alpha = round(0.13*N); % L0 gradient of output image 44.912877 dB SSIM 0.9952
% lambda  = 0.01;
% maxiter = 300; % maximum number of iterations
% eta = 1.0; % controling gamma for nonconvex optimization 
% epsilon = 0.0002*N; % stopping criterion 
% mu=0.5;
%% indian_02
beta = 0.6; %     45.85                                                                                  ; % stepsize of ADMM 36.721678 dB SSIMΪ 0.9706
nu=beta*[1 1 1];
alpha = round(0.14*N); % L0 gradient of output image 
lambda  = 0.01;
maxiter = 200; % maximum number of iterations
eta = 1.0; % controling gamma for nonconvex optimization 
epsilon = 0.0002*N; % stopping criterion 
mu=0.5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['L0radius: ' num2str(alpha)]);

%% definitions for Algorithm 1

% difference operators (periodic boundary)
D = @(z) cat(4, z([2:end, 1],:,:) - z, z(:,[2:end, 1],:)-z);
Dt = @(z) [-z(1,:,:,1)+z(end,:,:,1); - z(2:end,:,:,1) + z(1:end-1,:,:,1)] ...
    +[-z(:,1,:,2)+z(:,end,:,2), - z(:,2:end,:,2) + z(:,1:end-1,:,2)];
% for fftbased diagonilization
Lap = zeros(imsize(1),imsize(2));
Lap(1,1) = 4; Lap(1,2) = -1; Lap(2,1) = -1; Lap(end,1) = -1; Lap(1,end) = -1;
Lap = fft2(repmat(Lap, [1,1,dim]));

% calculating L0 gradient value
L0gradcalc = @(z) func_L0Gradvalue(D(double( z) ) );
y=Y(:,:,1);
% variables
v = D(u);
w = zeros(size(v));
Z1 = S;
Z2 = S;
Z3 = S;

M1 = Z1; 
M2 = Z2;
M3 = Z3;
%% main loop
disp('ADMM for L0 gradient projection is running...')
tic;
for iter = 1:maxiter
lastu=u;
         %% update u   
    temp= (Z1-M1/nu(1)) + (Z2-M2/nu(2)) + (Z3-M3/nu(3));
    
    rhs = 2*mu*(Y-S) +( Dt(v-w/beta)+(temp))*beta;
    u = real(ifftn((fftn(rhs))./((3+Lap)*beta+mu*2)));   
     %% update Z
     L1 = permute(u,[2,3,1]);  L2 = permute(u,[3,1,2]);  L3 = u;
    m1 = permute(M1,[2,3,1]); m2 = permute(M2,[3,1,2]); m3 = M3;
    
   
    tau = alpha_m./nu;
    Z1 = ipermute(prox_tnn_w(L1+m1/nu(1),tau(1)),[2,3,1]);
    Z2 = ipermute(prox_tnn_w(L2+m2/nu(2),tau(2)),[3,1,2]);
    Z3 = prox_tnn_w(L3+m3/nu(3),tau(3)); 
    %% update s
     S=SoftTh(Y-u,lambda/mu);

     %% update v
    v = ProjL10ball(D(u)+w/beta, alpha);
    
    w = w + beta*(D(u) - v);
    
    
    M1 = M1 + nu(1)*(u-Z1);
    M2 = M2 + nu(2)*(u-Z2);
    M3 = M3 + nu(3)*(u-Z3);
    mu = min(eta*mu,10);
    
     cc=reshape(C,m*n,dim);
     xx=reshape(u,m*n,dim);
%      psnrlist(iter)=psnr(xx,cc);
     errList(iter) = norm(u(:)-lastu(:)) / (norm(lastu(:)));
    L0Grad = L0gradcalc(u);
    if abs(L0Grad - alpha) < epsilon
        break;
    end
    
end
toc;
disp(['L0Grad = ', num2str(L0Grad), ' Iter = ', num2str(iter)]);
u_output =u;
%% result plot
 IndianWSWNNMl0TVresult=calcDenoiseResult( C,u_input, u,'Indian SSTV',false );
 msacase1=MSA(C,u);
ergascase1 = ErrRelGlobAdimSyn(C,u);

A=reshape(C,m*n,dim);
B=reshape(u,m*n,dim);
msad = mSAD(A,B);
% figure, plot(psnrlist);

figure,imshow(u(:,:,15),[]);


%% Soft Thresholding
function X=SoftTh(B,lambda)
      
       X=sign(B).*max(0,abs(B)-(lambda/2));
       
end
