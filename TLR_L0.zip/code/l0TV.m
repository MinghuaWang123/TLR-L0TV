%% L0 Gradient Projection

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Shunsuke Ono (ono@isl.titech.ac.jp)
% Last version: Dec 27, 2016
% Article: S. Ono, ``$L_0$ Gradient Projection,'', IEEE Transactions on
% Image Processing, vol. 26, no. 4, pp. 1554-1564, 2017.
% Test images: https://pixabay.com/en/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear;clc;

load Indiancom_case1.mat;


u_input=T;
[m,n,dim]=size(T);
Y=T;
S=zeros(m,n,dim);
u=S;
imsize = size(u);
dim=imsize(3);
N = imsize(1)*(imsize(2)); % number of pixels
%%%%%%%%%%%%%%%%%%%%% User Settings %%%%%%%%%%%%%%%%%%%%%%%%%%%%
alpha = round(0.13*N); % L0 gradient of output image
maxiter = 100; % maximum number of iterations
gamma = 1.5; % stepsize of ADMM  
eta = 0.97; % controling gamma for nonconvex optimization 0.96 35.263983 dB SSIMΪ 0.9513
epsilon = 0.0002*N; % stopping criterion 
lambda  = 0.3; %41.32 dB SSIMΪ 0.9852

% gamma = 20; % stepsize of ADMM 20 36.172973 dB SSIM 0.9667
% alpha = round(0.15*N); % L0 gradient of output image 35.596866 dB SSIM 0.9590
% lambda  = 0.01;
% maxiter = 100; % maximum number of iterations
% eta = 0.96; % controling gamma for nonconvex optimization 0.96 35.263983 dB SSIM 0.9513
% epsilon = 0.0002*N; % stopping criterion 

% gamma = 2; % stepsize of ADMM 20  35.850914 dB SSIM 0.96521
% alpha = round(0.10*N); % L0 gradient of output image
% lambda  = 0.05;
% maxiter = 1000; % maximum number of iterations
% eta = 0.97; % controling gamma for nonconvex optimization 
% epsilon = 0.0002*N; % stopping criterion 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['L0radius: ' num2str(alpha)]);

%% definitions for Algorithm 1

% difference operators (periodic boundary)
D = @(z) cat(4, z([2:end, 1],:,:) - z, z(:,[2:end, 1],:)-z);
Dt = @(z) [-z(1,:,:,1)+z(end,:,:,1); - z(2:end,:,:,1) + z(1:end-1,:,:,1)] ...
    +[-z(:,1,:,2)+z(:,end,:,2), - z(:,2:end,:,2) + z(:,1:end-1,:,2)];
% for fftbased diagonilization
Lap = zeros(imsize(1),imsize(2));
Lap(1,1) = 4; Lap(1,2) = -1; Lap(2,1) = -1; Lap(end,1) = -1; Lap(1,end) = -1;
Lap = fft2(repmat(Lap, [1,1,dim]));

% calculating L0 gradient value
L0gradcalc = @(z) func_L0Gradvalue(D(double( z) ) );
y=Y(:,:,1);
% variables
v = D(u);
w = v;

%% main loop
disp('ADMM for L0 gradient projection is running...')
tic;
for iter = 1:maxiter
   
         %% update u   
    rhs = (Y-S) + Dt(v-w)/gamma;
    u = real(ifftn((fftn(rhs))./(Lap/gamma+1)));   
    
    u1=u(:,:,1);
    
    d1=Dt(v-w)/gamma;
    d11=d1(:,:,1);
    
    aa=(Lap/gamma+1);   
    aa1=aa(:,:,1);
    
    rhs1=rhs(:,:,1);
    %% update s
     S=SoftTh(Y-u,lambda);
    S1=S(:,:,1);
     %% update v
    v = ProjL10ball(D(u)+w,alpha);    
    
    w = w + D(u) - v;
     gamma = eta*gamma;
    
    cc=reshape(C,m*n,dim);
     xx=reshape(u,m*n,dim);
%      psnrlist(iter)=psnr(xx,cc)
     
    L0Grad = L0gradcalc(u);
    if abs(L0Grad - alpha) < epsilon
        break;
    end
    
end
toc;
disp(['L0Grad = ', num2str(L0Grad), ' Iter = ', num2str(iter)]);

u_output =u;
%% result plot
 Indianl0TVresult=calcDenoiseResult( C,u_input, u,'Indian l0TV',false );
% figure, plot(psnrlist);

figure,imshow(C(:,:,65),[]);
figure,imshow(T(:,:,65),[]);
figure,imshow(u(:,:,65),[]);


%% Soft Thresholding
function X=SoftTh(B,lambda)
      
       X=sign(B).*max(0,abs(B)-(lambda/2));
       
end
