%% L0 Gradient Projection

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Shunsuke Ono (ono@isl.titech.ac.jp)
% Last version: Dec 27, 2016
% Article: S. Ono, ``$L_0$ Gradient Projection,'', IEEE Transactions on
% Image Processing, vol. 26, no. 4, pp. 1554-1564, 2017.
% Test images: https://pixabay.com/en/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;
close all;
addpath subfunctions
addpath images

imname = 'pixabay026.jpg';
u_input = double(imread(imname))/255; % input image
dim=3;

% load Indiancom_same_snr1020_imp0.mat;
% Omsi=img;
% u_input=Omsi;
% [m,n,dim]=size(noisy);
% Y=noisy;

imsize = size(u_input);
N = imsize(1)*(imsize(2)); % number of pixels
%%%%%%%%%%%%%%%%%%%%% User Settings %%%%%%%%%%%%%%%%%%%%%%%%%%%%
alpha = round(0.08*N); % L0 gradient of output image
maxiter = 40; % maximum number of iterations
gamma = 2; % stepsize of ADMM
eta = 0.95; % controling gamma for nonconvex optimization
epsilon = 0.0002*N; % stopping criterion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['L0radius: ' num2str(alpha)]);

%% definitions for Algorithm 1

% difference operators (periodic boundary)
D = @(z) cat(4, z([2:end, 1],:,:) - z, z(:,[2:end, 1],:)-z);
Dt = @(z) [-z(1,:,:,1)+z(end,:,:,1); - z(2:end,:,:,1) + z(1:end-1,:,:,1)] ...
    +[-z(:,1,:,2)+z(:,end,:,2), - z(:,2:end,:,2) + z(:,1:end-1,:,2)];
% for fftbased diagonilization
Lap = zeros(imsize(1),imsize(2));
Lap(1,1) = 4; Lap(1,2) = -1; Lap(2,1) = -1; Lap(end,1) = -1; Lap(1,end) = -1;
Lap = fft2(repmat(Lap, [1,1,dim]));

% calculating L0 gradient value
L0gradcalc = @(z) func_L0Gradvalue(D(double( uint8(z) ) ) );

% variables
v = D(u_input);
w = v;

%% main loop
disp('ADMM for L0 gradient projection is running...')
for iter = 1:maxiter
    
    rhs = u_input + Dt(v-w)/gamma;
    u = real(ifft2((fft2(rhs))./(Lap/gamma+1)));    
    v = ProjL10ball(D(u)+w, alpha);
    w = w + D(u) - v;
    
    gamma = eta*gamma;
    
    L0Grad = L0gradcalc(u);
    if abs(L0Grad - alpha) < epsilon
        break;
    end
    
end

disp(['L0Grad = ', num2str(L0Grad), ' Iter = ', num2str(iter)]);
 u_output = round(u*255)/255; % output image
figure,imshow(u_input(:,:,1),[]);
figure,imshow(u_output(:,:,1),[]);
figure,imshow(u(:,:,1),[]);

%% result plot

plotsize = [1, 2];
% ImgPlot(u_input, 'Input', 1, [plotsize,1]);
% ImgPlot(u_output, 'Output', 1, [plotsize,2]);

[tv1,dx1,dy1,a1,nonz1]= f_1norm_tv(u_input);
[tv2,dx2,dy2,a2,nonz2]= f_1norm_tv(u_output);
[tv3,dx3,dy3,a3,nonz3]= f_1norm_tv(u);