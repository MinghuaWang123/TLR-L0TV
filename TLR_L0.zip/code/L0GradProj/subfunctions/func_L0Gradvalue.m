% Author: Shunsuke Ono (ono@isl.titech.ac.jp)
function[L0TV] = func_L0Gradvalue(Du) % input range [0,255]

Du(end,:,:,1) = 0;
Du(:,end,:,2) = 0;
L0TV = nnz(round(sum(sum(abs(Du),4),3)));
