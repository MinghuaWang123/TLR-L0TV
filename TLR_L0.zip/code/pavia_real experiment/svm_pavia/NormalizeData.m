% Normalizing the data in the dataset
% Written by Abbas Hosseini <a_hosseini@ce.sharif.edu>
% Copyright 2012 by Abbas Hosseini

function dataset = NormalizeData( dataset )

for i=1:size(dataset.data,2)
    dataset.data(:,i)=dataset.data(:,i)/norm(dataset.data(:,i));
end

end

