% Run SVM for a specific set of parameters without cross validation

clc;
clear;

%datasetName='indian_pines';
datasetName='pavia_univ';
%datasetName='pavia_center';

load (sprintf('../DataSets/HSI_%sW.mat',datasetName));

rng(0);
% comment next two lines for any dataset other than indian pines
% Percent = 10;      % Percent of data used for training
% IndianPinesScript; % Assign test and train indices
%

%--- Method parameters
param.degree=9;    % Degree of the polynomial kernel
param.C=10^0;       % SVM tradeoff variable

tic;
dataset=NormalizeData(dataset);
%SVM Learning
model = svmtrain(dataset.labels(dataset.trainInd),dataset.data(:,dataset.trainInd)',sprintf('-q -g 1 -t 1 -d %d -r 1 -c %f',param.degree,param.C));
% Predict test labels
tlabs = svmpredict(dataset.labels(dataset.testInd),dataset.data(:,dataset.testInd)', model);
toc

[kappa acc acc_O acc_A] = evaluate_results(tlabs, dataset.labels(dataset.testInd));
% HSI_PlotResults( dataset, tlabs );