% IndianPinesScript
% Set random test and train data
%c = max(dataset.labels);
c = max(dataset.labels) - min(dataset.labels);
% c=[1 10 11 12 13 14];
% Trp = [48 1290 750 210 447 672 23 440 18 871 2221 552 190 1164 342 85];
% trp 0= [30 150 150 150 150 150 20  150 15 150 150 150 150 150 150 50];
% trp 1= [6 144 84 24 50 75 3 49 2 97 247 62 22 130 38 10];
% trp 2= [20 144 100 50 50 75 10 49 10 200 247 100 22 130 80 40];
% trp 3= [20 144 100 100 100 100 10 49 10 200 247 120 22 130 80 50];
% trp = [20 150 150 100 100 100 10 50 10 200 250 120 30 130 80 50];%ÿһ���ѵ����������
num=[521 957 110 226 698 3042 1330 630 428];%�ܸ���
% num=[391 1343 616 1525 674 799];%�ܸ���
% num=[2009 3726 1976 1394 2678 3959 3579 11271 6203 3278 1068 1927 916 1070 7268 1807];%�ܸ���
trp =ceil(0.1*num);
Tidx = [];
tidx = [];
%Percent=2;%�ٷ�֮����
for i = 1:c
    Ic = find( dataset.labels == i );
    L = length(Ic);
    idx = randperm(L);
%     Tidx = [Tidx; Ic(idx(1:ceil(Trp(i)/(100/Percent))))];
%     tidx = [tidx; Ic(idx(ceil(Trp(i)/(100/Percent))+1:end))];
%     Tidx = [Tidx; Ic(idx(1:ceil(trp(i)/(10/Percent))))];
%     tidx = [tidx; Ic(idx(ceil(trp(i)/(10/Percent))+1:end))];
%     Tidx = [Tidx; Ic(idx(1:ceil(L/(10/Percent))))];
%     tidx = [tidx; Ic(idx(ceil(L/(10/Percent))+1:end))];
    Tidx = [Tidx; Ic(idx(1:trp(i)))];      %ѵ�����±�
    tidx = [tidx; Ic(idx(trp(i)+1:end))];   %���Լ��±�
end
dataset.trainInd = sort(Tidx);
dataset.testInd = sort(tidx);