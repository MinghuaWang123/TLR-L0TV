% Create datasets in the following format

%       dataset: structure of
%                   cord:       N-by-2 matrix of N coordinates
%                   labels:     N-by-1 matrix of N corresponding labels
%                   data:       D-by-N matrix of N corresponding D dimensional features
%                   moment:     D-by-N matrix of N corresponding D or 2xD dimensional moments
%                   colormap:   256-by-3 matrix of class color codes
%                   testInd:    M-by-1 matrix of indices of test data
%                   trainInd:   T-by-1 matrix of indices of train data

% --- Indian Pines ---

% Original data in: DataSets/Indian/92AV3C.tif - downoald from
% https://engineering.purdue.edu/?biehl/MultiSpec/hyperspectral.html
% ground truth in: DataSets/Indian/Indian_pines_c
% colormap in: DataSets/Indian/Indian_pines_color
% clc;clear;
%indian_pines = imread('DataSets/Indian/92AV3C.tif');
% load 'indian_LRMR';
load 'PaviaUA_gt';
% load 'Indian_pines_color';
%indian_pines(:,:, [104:108 150:163 220]) = [];
orig_lab = paviaUA_gt;
%orig_data = indian_pines;
% orig_data = indian_pines_corrected;
orig_data = u;
[I,J] = find( orig_lab+1 );

cord = [I,J];

N = size(cord,1);
D = size(orig_data,3);

labels = zeros(N,1);
data = zeros(D,N);

for i = 1:N
    data(:,i) = reshape( orig_data(I(i),J(i),:), D, 1);
    labels(i) = orig_lab( I(i),J(i) );
end

dataset.labels = labels;
dataset.cord = cord;
dataset.data = data;
dataset.colormap = colormap;
% test and train indices are chosen randomly at test time
% moments are loaded later when window size is chosen

save( 'HSI_PaviaUA_wswtnnl0htvW', 'dataset' );
%save( 'DataSets/HSI_indian_pinesWNoisy', 'dataset' ); Use if noisy band are not removed

% load 'DataSets/HSI_indian_pinesW.mat';
% % % generate moments for different window sizes
% for window = [3 5 7 9]
%     [patchwiseMean, patchwiseStd] = compute_moments(dataset, window);
%     save( sprintf( 'DataSets/HSI_indian_pinesW_N_%d', window ), 'patchwiseMean', 'patchwiseStd' );
%     [patchwiseMean, patchwiseStd] = compute_moments_N(dataset, window);
%     save( sprintf( 'DataSets/HSI_indian_pinesW_%d', window ), 'patchwiseMean', 'patchwiseStd' );
% end


% --- Univ. of Pavia & Center of Pavia --- %
%
% The datasets were kindly provided by Paolo Gamba <paolo.gamba@unipv.it>
% of the University of Pavia, Italy.
%
% For these datasets, please format the datasets into the above format
% after you accuire the datasets and generate similar files for moments
%
% Thank you.
%


