% Run SVM with 5-fold cross validation

% clc;
% clear;

datasetName='PaviaUA_wswtnnl0htv';
% datasetName='pavia_univ';
%datasetName='pavia_center';

load (sprintf('HSI_%sW.mat',datasetName));

% Change the following line only for InianPines Dataset
NumofRuns=1;

param.degree=1;    % Degree of the polynomial kernel
param.C=1;       % SVM tradeoff variable

dataset=NormalizeData(dataset);
tic
for RUN = 1:NumofRuns
    rng(RUN-1);          % To obtain the results change the seed from 0 to 9
    % comment next two lines for any dataset other than indian pines
    Percent = 10;       % Percent of data used for training
    paviaScript; % Assign test and train indices
    
    best_param = param;
    best_cv_acc = 0;
    
    % Cross validation
    for degree=7
        param.degree=degree;
        for ic=-1:7
            param.C=10^ic;
            CVaccuracy = svmtrain(dataset.labels(dataset.trainInd),dataset.data(:,dataset.trainInd)',sprintf('-q -g 1 -t 1 -d %d -r 1 -c %d -v 5',param.degree,param.C));
            if(CVaccuracy>best_cv_acc)
                best_param = param;
                best_cv_acc = CVaccuracy;
            end
        end
    end
    
    % Perform learning using best parameters obtained by CV
    param = best_param;
    model = svmtrain(dataset.labels(dataset.trainInd),dataset.data(:,dataset.trainInd)',sprintf('-q -g 1 -t 1 -d %d -r 1 -c %d',param.degree,param.C));
    tlabs = svmpredict(dataset.labels(dataset.testInd),dataset.data(:,dataset.testInd)', model);
    [kappa acc acc_O acc_A] = evaluate_results(tlabs, dataset.labels(dataset.testInd));
    
    % Save results of each run
    testInd = dataset.testInd;
    trainInd = dataset.trainInd;
    str = sprintf( '../Results/SVM/%s_Percent_%d_Run_%d', datasetName, Percent, RUN );
%     save( str, 'best_param', 'kappa', 'acc', 'acc_O', 'acc_A', 'testInd', 'trainInd', 'tlabs' );
    
end
toc
  HSI_PlotResults( dataset, tlabs );
