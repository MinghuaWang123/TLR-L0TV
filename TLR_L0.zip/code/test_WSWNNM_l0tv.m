%% WSWNN-L0TV

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Minghua Wang (minghuawang1993@163.com)
% Last version: Jul. 27, 2019
% Article: Tensor Low-Rank Constraint and l0 Total Variation for Hyperspectral Image Mixed Noise Removal
% https://ieeexplore.ieee.org/document/9352482/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear;clc;

load Indiancom_case6.mat;

u_input=T;
[m,n,dim]=size(T);
mn=m*n;
Y=T;
S=zeros(m,n,dim);
u=Y-S;
imsize = size(u_input);

N = imsize(1)*(imsize(2)); % number of pixels
%%%%%%%%%%%%%%%%%%%%% User Settings %%%%%%%%%%%%%%%%%%%%%%%%%%%%
etol=10^(-4);

M = cell(ndims(C), 1);
Y1 = M;% admm����
for i = 1:ndims(C)
    M{i} = S;
    Y1{i} = zeros(m,n,dim);
end

% beta = 1;
Msum = zeros(m,n,dim);
Ysum = zeros(m,n,dim);
alpha_m=[1,1,1000];
alpha_m=alpha_m/sum(alpha_m);
%% indian_01
beta = 0.2;                                                                                                                              ; % stepsize of ADMM 36.721678 dB SSIMΪ 0.9706
alpha = round(0.14*N); % 40.88
lambda  = 0.01;
maxiter = 200; % maximum number of iterations
eta = 1.0; % controling gamma for nonconvex optimization 
epsilon = 0.0002*N; % stopping criterion 
mu=0.5;%47.82
%% indian_02
% beta = 0.4; %       45.492810 dB SSIMΪ 0.9957                                                                                                                      ; % stepsize of ADMM 36.721678 dB SSIMΪ 0.9706
% alpha = round(0.14*N); % L0 gradient of output image 
% lambda  = 0.01;
% maxiter = 300; % maximum number of iterations
% eta = 1.0; % controling gamma for nonconvex optimization 
% epsilon = 0.0002*N; % stopping criterion 
% mu=0.5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['L0radius: ' num2str(alpha)]);

%% definitions for Algorithm 1

% difference operators (periodic boundary)
D = @(z) cat(4, z([2:end, 1],:,:) - z, z(:,[2:end, 1],:)-z);
Dt = @(z) [-z(1,:,:,1)+z(end,:,:,1); - z(2:end,:,:,1) + z(1:end-1,:,:,1)] ...
    +[-z(:,1,:,2)+z(:,end,:,2), - z(:,2:end,:,2) + z(:,1:end-1,:,2)];
% for fftbased diagonilization
Lap = zeros(imsize(1),imsize(2));
Lap(1,1) = 4; Lap(1,2) = -1; Lap(2,1) = -1; Lap(end,1) = -1; Lap(1,end) = -1;
Lap = fft2(repmat(Lap, [1,1,dim]));


% calculating L0 gradient value
L0gradcalc = @(z) func_L0Gradvalue(D(double( z) ) );
y=Y(:,:,1);
% variables
v = D(u);
w = zeros(size(v));

%% main loop
disp('ADMM for L0 gradient projection is running...')
tic;
for iter = 1:maxiter
%      nu=1/(gamma);
lastu=u;
         %% update u   
    temp=(Msum-Ysum/beta);
    
    rhs = 2*mu*(Y-S) +( Dt(v-w/beta)+(temp))*beta;
    u = real(ifftn((fftn(rhs))./((3+Lap)*beta+mu*2)));   
    
   %% solve M
    Msum = 0*Msum;
    Ysum = 0*Ysum;
    for i = 1:ndims(T)
   %       M{i} = Fold(Pro2TraceNorm(Unfold(X+Y1{i}, dim, i), alpha(i)/(2*beta)), dim, i);
        M{i} = Fold(Pro2TraceWNNM(Unfold(u+Y1{i}/beta, [m,n,dim], i), alpha_m(i)/beta), [m,n,dim], i);%����WNNM SVT
        Msum = Msum + M{i};
        Ysum = Ysum + Y1{i};
    end
    
    
    %% update s
     S=SoftTh(Y-u,lambda/mu);
     %% update v
    v = ProjL10ball(D(u)+w/beta, alpha);
    
    w = w + beta*(D(u) - v);
    
    
    for i = 1:ndims(T)
        Y1{i} = Y1{i} +beta*( u-M{i});
    end
   mu = min(eta*mu,10);
    
    cc=reshape(C,m*n,dim);
     xx=reshape(u,m*n,dim);
%      psnrlist(iter)=psnr(xx,cc);
          errList(iter) = norm(u(:)-lastu(:)) / (norm(lastu(:)));

    L0Grad = L0gradcalc(u);
    if abs(L0Grad - alpha) < epsilon
        break;
    end
    
end
toc;
disp(['L0Grad = ', num2str(L0Grad), ' Iter = ', num2str(iter)]);

u_output =u;
%% result plot
 IndianWSWNNMl0TVresult=calcDenoiseResult( C,u_input, u,'Indian WSWNNL0TV',false );
 msacase1=MSA(C,u);
ergascase1 = ErrRelGlobAdimSyn(C,u);

A=reshape(C,m*n,dim);
B=reshape(u,m*n,dim);
msad = mSAD(A,B);
figure, plot(psnrlist);

figure,imshow(u_input(:,:,1),[]);
figure,imshow(C(:,:,1),[]);
figure,imshow(u(:,:,1),[]);
figure,imshow(S(:,:,1),[]);


%% Soft Thresholding
function X=SoftTh(B,lambda)
      
       X=sign(B).*max(0,abs(B)-(lambda/2));
       
end
